﻿AFK Realm bot map extraction tools
From SquidBots (https://github.com/Zyth45/squidbots-dashboard), MIT licensed.
Northrend map 571 added for AFK Realm.
These tools read the user's own game client; no map images are bundled.
